---
layout:     post
title:      An-Example
subtitle:   一个例子
date:       1997-01-01
author:     Huang
header-img: img/post-bg-test.jfif
catalog: true
tags:
    - One-Tag
    - Another-Tag
---

### 前言

这是博文的一个模板，下面逐一解释各个东西的含义：

`layout`: 采用哪一个博客模板，有default, keynote, page, post四种，一般只需要使用post

`title`: 文章标题，可以有空格、中文，不需要与markdown文件名保持一致，但是我习惯保持一致

`subtitle`: 副标题，一般是解释主标题的简单短语或句子

`date`: 博文发表日期，YYYY-MM-DD风格

`author`: 文章作者

`header-img`: 选取存放于根目录下的img文件夹的文件，命名随意，但最好保持一个标准

`catalog`: 旁栏帮助定位

`tags`: 该博文的标签，帮助访问者浏览其他相关博文

### 可以修改的东西

* `img`文件夹:  
  * `404-bg.jpg`: 404 Not Found的页面图像，最好还是不要修改，这个挺经典的
  * `about-Huang.jpg`: 我的头像
  * `apple-touch-icon.png`: 安装网站之后的图标
  * `favicon.ico`: 网站图标
  * `post-bg-desk.jpg`: index界面的背景
  * `post-bg-rwd.jpg`: about界面的背景
  * `post-bg-test.jfif`: 该界面的背景，可以删去
  * `tag-bg.jpg`: tags的背景

* `_config.yml`: 有些东西不再讲解，一望即知
  * `SEOTitle`: 搜索结果的大标题
  * `description`: 个性签名
  * `sidebar-about-description`: 另一个个性签名
  * 其他的可以
* `_includes/head.html`: 查找`google-site-verification` 修改之后的`content`为自己的google console给的代码，然后就可以在google搜索`site:your-name.github.io`，然后就知道你的网站是否被收录了
* `about.html`: 个人介绍界面，用html自己修改就行

上面的都是最简单的修改，如果需要更深层次的修改，那就自己把项目大致走一遍然后修改。

其实修改这么多已经够了，毕竟你是写博客，又不是干别的。

