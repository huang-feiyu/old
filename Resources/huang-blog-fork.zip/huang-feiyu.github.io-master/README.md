### 前言

* 使用方法：本地建立一个文件夹将这一整个文件解压进去，根据指引创建更改一些简单的配置。之后在[github](https://github.com)上建一个名字为`${Your_name}$.github.io`的仓库，把一整个文件夹上传到仓库中去，然后就可以访问了。——这就是最顶级开发者社区的风范，你想干什么就干什么，I don’t care，我只需要你对于开源和编程的**热爱**

* **这是[Huang Blog](https://huang-feiyu.github.io/)的fork版本，可以根据<a href="./_posts/1997-01-01-An-Example">简单介绍</a>建立一个简单的博客。**——如果还是不会搭建，可以给我发邮件`0711feiyu@gmail.com`

### 简单指引

> 其实就是把简单介绍里面的东西复制了一份

* `img`文件夹:  
  * `404-bg.jpg`: 404 Not Found的页面图像，最好还是不要修改，这个挺经典的
  * `about-Huang.jpg`: 我的头像
  * `apple-touch-icon.png`: 安装网站之后的图标
  * `favicon.ico`: 网站图标
  * `post-bg-desk.jpg`: index界面的背景
  * `post-bg-rwd.jpg`: about界面的背景
  * `post-bg-test.jfif`: 该界面的背景，可以删去
  * `tag-bg.jpg`: tags的背景

* `_config.yml`: 有些东西不再讲解，一望即知
  * `SEOTitle`: 搜索结果的大标题
  * `description`: 个性签名
  * `sidebar-about-description`: 另一个个性签名
  * 其他的可以
* `_includes/head.html`: 查找`google-site-verification` 修改之后的`content`为自己的google console给的代码，然后就可以在google搜索`site:your-name.github.io`，然后就知道你的网站是否被收录了
* `about.html`: 个人介绍界面，用html自己修改就行

上面的都是最简单的修改，如果需要更深层次的修改，那就自己把项目大致走一遍然后修改(没什么难度，连代码都不需要怎么写)。当然，如果你厌恶别人的名字，可以在Linux系统中使用`grep`命令索引所有的文件，查找然后修改。

其实修改这么多已经够了，毕竟你是写博客，又不是干别的。

### 博客引路

* 了解自己为什么写博客：
  * 记录笔记
  * 记录自己之前的思想(我们思想在剧变，我想这个是最重要的)
  * 写技术博客提升影响力(这个需要学习提高SEO)
  * 帮助他人——这个就随缘了，也有可能会误导他人
  * 如果是记录生活的话，就不要用博客了——[B站](https://www.bilibili.com)，[豆瓣](https://douban.com)，朋友圈，QQ空间都可以使用
* 写什么：
  * 笔记：包括学习生活中的笔记、读过的书的摘抄(建议使用微信读书，可以复制)……
  * 散文：记录自己的思想，以及一些想法——会帮助到你的，却也耗时最长，但是值得
  * 技术博客：对算法的分析、对一个技术的理解总结等等
  * 他人的文章摘录：需要他人的允许，最好不要复制什么CSDN、掘金、博客园上面的文章，国内的开发者社区已经够乱了，别让它更乱
  * 还可以写其他很多：哲学、艺术、评论鉴赏、小说、诗歌……很多很多
* 怎么写：
  * 使用的工具：我写作使用的是[Typora](https://typora.io/)，因为可以实时预览——虽然没有vim插件，但是这是中文写作倒无所谓了
  * markdown文法：[markdown guide](https://www.markdownguide.org/)，该博客根据GitHub支持的markdown5文法渲染
  * 写作时间：一般是任何时间，但是我推荐早晨起床(干完饭)后、洗澡后、入睡前写作
  * 然后想写什么就写什么吧，毕竟我写的东西也不是很好

### 结语

我为什么要写这个？真是奇怪的自己。



